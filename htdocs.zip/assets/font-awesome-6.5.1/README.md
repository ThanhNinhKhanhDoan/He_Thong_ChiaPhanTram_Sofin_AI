# font-awesome-6.5.1-pro-full
Font Awesome v6.5.1 Pro Full
