<script>
    window.location.href = "<?=set_route_to_link(["public","edu_tier","tier_5"])?>";
</script>
