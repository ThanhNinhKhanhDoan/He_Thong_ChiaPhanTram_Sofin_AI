<?php
require $pathFileRules;
?>